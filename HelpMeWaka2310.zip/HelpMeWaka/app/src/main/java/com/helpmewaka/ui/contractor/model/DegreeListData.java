package com.helpmewaka.ui.contractor.model;

/**
 * Created by Ravindra Birla on 20/09/2019.
 */
public class DegreeListData {
    public String DEG_ID;
    public String Degree_Name;
    public String Year_Of_Pass;
}
