package com.helpmewaka.ui.model;

/**
 * Created by Ravindra Birla on 03/10/2019.
 */
public class PaymentData {
    public String JOB_ID;
    public String MILESTONE;
    public String TransactionID;
    public String InvoiceID;
    public String paymentMode;
    public String paymentDt;
    public String Amount;

}
