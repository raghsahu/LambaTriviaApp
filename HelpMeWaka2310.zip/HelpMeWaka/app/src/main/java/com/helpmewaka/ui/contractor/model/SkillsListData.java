package com.helpmewaka.ui.contractor.model;

/**
 * Created by Ravindra Birla on 20/09/2019.
 */
public class SkillsListData {
    public String SKL_ID;
    public String Skills;
}
