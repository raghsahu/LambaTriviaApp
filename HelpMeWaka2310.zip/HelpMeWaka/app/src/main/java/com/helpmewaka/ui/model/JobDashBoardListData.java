package com.helpmewaka.ui.model;

import java.io.Serializable;

/**
 * Created by Ravindra Birla on 17/09/2019.
 */
public class JobDashBoardListData implements Serializable {
    public String JobEndDtApprox;
    public String JOB_ID;
    public String CLT_ID;
    public String Service_State;
    public String PostDt;
    public String SERV_ID;
    public String Job_Title;
    public String Service_Requested;
    public String Special_Request;
    public String Job_Code;
    public String Job_Stat;
    public String Type;
    public String JobStrtDtApprox;
    public String paymentstatus;
    public String Dispute_Comments;
    public String Service_Country;
    public String Service_City;
    public String Task_Code;

}
