package com.helpmewaka.ui.model;

/**
 * Created by Ravindra Birla on 10/09/2019.
 */
public class UserInfoData {

    public String Email;
    public String user_id;
    public String LName;
    public String Address;
    public String Pic;
    public String City;
    public String FName;
    public String PinCode;
    public String Dob;
    public String State;
    public String Alternate_Num;
    public String Type;
    public String Contact_Num;
    public String Country;

    public String Reference_Address2;
    public String Reference_Address3;
    public String Reference_Address1;
    public String Salt;
    public String Reference_Phone3;
    public String Reference_Phone2;
    public String Reference_Name2;
    public String Reference_Name1;
    public String Reference_Phone1;
    public String ScanId_Proof;
    public String Reference_Name3;
    public String Reference_Email1;
    public String Reference_Email2;
    public String Reference_Email3;

}
