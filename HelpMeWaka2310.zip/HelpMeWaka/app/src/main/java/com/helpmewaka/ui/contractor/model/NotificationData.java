package com.helpmewaka.ui.contractor.model;

/**
 * Created by Ravindra Birla on 17/09/2019.
 */
public class NotificationData {
    public String UNT_ID;
    public String NotifyDesc;
    public String PostDt;
    public String User;
    public String UID;
}
