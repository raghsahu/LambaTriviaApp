package com.helpmewaka.ui.Config;

/**
 * Created by Ravindra Birla on 12/10/2019.
 */
public class PayPalConfig {

    public static final String PAYPAL_CLIENT_ID = "AQ9G2-ACJgg-hK8zjKP2Bz2XWrzbGcz3wOSbNL_wjGV5oWZeJIf1YEngQxHN_TcnzaOggXI-X2MlFPyA";
}
