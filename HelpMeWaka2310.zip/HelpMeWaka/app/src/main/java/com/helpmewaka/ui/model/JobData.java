package com.helpmewaka.ui.model;

/**
 * Created by Ravindra Birla on 30/09/2019.
 */
public class JobData {
    public String CLT_ID;
    public String JOB_ID;
    public String Job_Code;
    public String Job_Title;
    public String SERV_ID;
    public String Service_Requested;
    public String Special_Request;
    public String Service_Country;
    public String Service_State;
    public String Service_City;
    public String additional_info;
    public String Contact_Person;
    public String Contact_Number;
}
