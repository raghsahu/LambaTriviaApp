package com.helpmewaka.ui.contractor.model;

public class FileListContractData {
    public String CNT_ID;
    public String FileJOBID;
    public String Attachment;
    public String UploadDt;

}
