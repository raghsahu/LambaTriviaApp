package com.helpmewaka.ui.model;

/**
 * Created by Ravindra Birla on 23/09/2019.
 */
public class BillingData {
    public String CLT_ID;
    public String CNT_ID;
    public String Address;
    public String City;
    public String State;
    public String Type;
    public String Country;
    public String PinCode;
}
