package com.helpmewaka.ui.contractor.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.helpmewaka.R;
import com.helpmewaka.ui.server.API;
import com.helpmewaka.ui.server.Session;
import com.helpmewaka.ui.util.ToastClass;
import com.helpmewaka.ui.util.helper.NetworkUtil;

public class ActivityPaymentMilestone extends AppCompatActivity implements View.OnClickListener, SwipeRefreshLayout.OnRefreshListener{

    SwipeRefreshLayout swipeRefreshLayout;
    RecyclerView recycler_view;
    LinearLayout ll_no_record;
    String user_id;
    ImageView iv_back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_milestone);

        Session session = new Session(this);
        user_id = session.getUser().user_id;
        recycler_view = findViewById(R.id.recycler_view);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        ll_no_record = findViewById(R.id.ll_no_record);
        iv_back = findViewById(R.id.iv_back);

        clickListner();

        if (NetworkUtil.isNetworkConnected(ActivityPaymentMilestone.this)) {
            try {
                //CallGetContractFile(file_url);

            } catch (NullPointerException e) {
                ToastClass.showToast(ActivityPaymentMilestone.this, getString(R.string.too_slow));
            }
        } else {
            ToastClass.showToast(ActivityPaymentMilestone.this, getString(R.string.no_internet_access));
        }
    }

    private void clickListner() {
        iv_back.setOnClickListener(this);
        swipeRefreshLayout.setOnRefreshListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
//                Intent intent = new Intent(ActivityJobFileList.this, ActivityJobViewMoreCust.class);
//                intent.putExtra("JOBDATA", jobListData);
//                startActivity(intent);
//                finish();
                onBackPressed();
                break;


    }
    }

    @Override
    public void onRefresh() {
       // fileList.clear();
        // stopping swipe refresh
        swipeRefreshLayout.setRefreshing(false);
       // CallGetContractFile(file_url);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
