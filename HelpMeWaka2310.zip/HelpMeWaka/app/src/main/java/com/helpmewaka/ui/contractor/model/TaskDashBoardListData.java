package com.helpmewaka.ui.contractor.model;

import java.io.Serializable;

/**
 * Created by Ravindra Birla on 17/09/2019.
 */
public class TaskDashBoardListData implements Serializable {
    public String JOB_ID;
    public String CNT_ID;
    public String Job_Code;
    public String TASK_ID;
    public String Job_Title;
    public String AssignDt;
    public String JobStartDt;
    public String JobEndDt;

}
