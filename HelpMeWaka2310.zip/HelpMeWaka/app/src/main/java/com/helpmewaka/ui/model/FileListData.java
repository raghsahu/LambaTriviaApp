package com.helpmewaka.ui.model;

/**
 * Created by Ravindra Birla on 01/10/2019.
 */
public class FileListData {
    public String CLT_ID;
    public String JOB_ID;
    public String Image;
    public String UploadDt;
    public String Type;
}
