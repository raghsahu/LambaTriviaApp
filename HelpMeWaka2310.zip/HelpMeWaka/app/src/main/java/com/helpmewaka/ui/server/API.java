package com.helpmewaka.ui.server;

/**
 * Created by Ravindra Birla on 18,sep,2019
 */
public interface API {

//    String BASE_URL = "http://logicalsofttech.com/helpmewaka/api/";
//    String BASE_URL_IMG_CON = "https://logicalsofttech.com/helpmewaka/upload/contractor/profile/";
//    String BASE_URL_IMG_CUST = "https://logicalsofttech.com/helpmewaka/upload/customer/";
//    String BASE_URL_DOWNLOAD_IMG_CUST = "https://logicalsofttech.com/helpmewaka/upload/jobs/customer/";
//    String BASE_URL_DOWNLOAD_IMG_CONTRACTOR = "https://logicalsofttech.com/helpmewaka/upload/jobs/contractor/";
//    String BASE_URL_IMEGES = "https://www.helpmewaka.com/images/";

    String BASE_URL = "https://helpmewaka.com/api/";
    String BASE_URL_IMG_CON = "https://www.helpmewaka.com/upload/contractor/profile/";
    String BASE_URL_IMG_CUST = "https://www.helpmewaka.com/upload/customer/";
    String BASE_URL_DOWNLOAD_IMG_CUST = "https://www.helpmewaka.com/upload/jobs/customer/";
    String BASE_URL_DOWNLOAD_IMG_CONTRACTOR = "https://www.helpmewaka.com/upload/jobs/contractor/";
    String BASE_URL_IMEGES = "https://www.helpmewaka.com/images/";

}

    //https://www.helpmewaka.com/upload/contractor/photocopy/